package com.service;

import com.dto.PageDTO;

public interface MapService {

	public PageDTO findAll(int curPage);
}
