package com.controller;

import com.service.MapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MapController {

    @Autowired
    MapService service;

    @GetMapping("/main")
    public String main(Model m) {

        return "main";
    }

}
