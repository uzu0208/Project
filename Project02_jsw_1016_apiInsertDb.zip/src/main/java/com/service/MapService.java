package com.service;

import com.dto.MapDTO;

import java.util.List;

public interface MapService {

    public int loadApi(MapDTO dto);
}
