package com.service;

import java.util.List;

import com.dto.MapDTO;

public interface MapService {

	public List<MapDTO> findAll();
}
