package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dto.PageDTO;
import com.service.MapService;

@Controller
public class MapController {
	
	@Autowired
	MapService service;
	
	@GetMapping("/main")  
	// http://localhost:8090/app/main
	public String main(Model m, @RequestParam (value="curPage", required = false, defaultValue = "1") int curPage) {
		
		PageDTO pagedto = service.findAll(curPage);
		m.addAttribute("pagedto",pagedto);
		
		return "main"; // view 정보 --> /WEB-INF/views/main.jsp
	}
	
	@GetMapping("/search")  
	public String search(Model m, @RequestParam (value="curPage", required = false, defaultValue = "1") int curPage) {
		
		PageDTO pagedto = service.findAll(curPage);
		m.addAttribute("pagedto",pagedto);
		
		return "main"; // view 정보 --> /WEB-INF/views/main.jsp
	}

}
